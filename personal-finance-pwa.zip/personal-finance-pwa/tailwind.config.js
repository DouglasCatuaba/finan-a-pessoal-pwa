/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#2563eb',
          hover: '#1d4ed8',
        },
        success: '#16a34a',
        warning: '#f59e0b',
        danger: '#dc2626',
        light: {
          text: '#0f172a',
          background: '#f8fafc',
        },
        dark: {
          background: '#0b1220',
          cards: '#111827',
          text: '#e5e7eb',
        },
      },
    },
  },
  plugins: [],
}

