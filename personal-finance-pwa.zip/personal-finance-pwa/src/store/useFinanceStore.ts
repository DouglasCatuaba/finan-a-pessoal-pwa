import { create } from 'zustand';
import type { Transaction, Recurring, Budget, Rule } from '../db';

interface FinanceState {
  transactions: Transaction[];
  recurrings: Recurring[];
  budgets: Budget[];
  rules: Rule[];
  currentPage: string;
  isAddTransactionModalOpen: boolean;
  selectedTransaction: Transaction | null;
  
  // Actions
  setCurrentPage: (page: string) => void;
  setTransactions: (transactions: Transaction[]) => void;
  addTransaction: (transaction: Transaction) => void;
  updateTransaction: (id: number, transaction: Partial<Transaction>) => void;
  deleteTransaction: (id: number) => void;
  setRecurrings: (recurrings: Recurring[]) => void;
  setBudgets: (budgets: Budget[]) => void;
  setRules: (rules: Rule[]) => void;
  openAddTransactionModal: () => void;
  closeAddTransactionModal: () => void;
  setSelectedTransaction: (transaction: Transaction | null) => void;
}

export const useFinanceStore = create<FinanceState>((set) => ({
  transactions: [],
  recurrings: [],
  budgets: [],
  rules: [],
  currentPage: 'dashboard',
  isAddTransactionModalOpen: false,
  selectedTransaction: null,
  
  setCurrentPage: (page) => set({ currentPage: page }),
  setTransactions: (transactions) => set({ transactions }),
  addTransaction: (transaction) => set((state) => ({ 
    transactions: [...state.transactions, transaction] 
  })),
  updateTransaction: (id, updatedTransaction) => set((state) => ({
    transactions: state.transactions.map(t => 
      t.id === id ? { ...t, ...updatedTransaction } : t
    )
  })),
  deleteTransaction: (id) => set((state) => ({
    transactions: state.transactions.filter(t => t.id !== id)
  })),
  setRecurrings: (recurrings) => set({ recurrings }),
  setBudgets: (budgets) => set({ budgets }),
  setRules: (rules) => set({ rules }),
  openAddTransactionModal: () => set({ isAddTransactionModalOpen: true }),
  closeAddTransactionModal: () => set({ 
    isAddTransactionModalOpen: false, 
    selectedTransaction: null 
  }),
  setSelectedTransaction: (transaction) => set({ selectedTransaction: transaction }),
}));

