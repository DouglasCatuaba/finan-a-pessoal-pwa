import React, { useState } from 'react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Card from '../../components/Card';
import Button from '../../components/Button';
import { useFinanceStore } from '../../store/useFinanceStore';
import { formatCurrency } from '../../utils/formatCurrency';
import { getCurrentMonth, getMonthName } from '../../utils/dateHelpers';
import { calculateMonthlyMetrics, calculateExpensesByCategory, calculateLast6MonthsBalance } from '../../utils/calcMetrics';

const Dashboard: React.FC = () => {
  const { transactions } = useFinanceStore();
  const [selectedMonth, setSelectedMonth] = useState(getCurrentMonth());

  const monthlyMetrics = calculateMonthlyMetrics(transactions, selectedMonth);
  const expensesByCategory = calculateExpensesByCategory(transactions, selectedMonth);
  const last6MonthsBalance = calculateLast6MonthsBalance(transactions);

  const COLORS = ['#2563eb', '#16a34a', '#f59e0b', '#dc2626', '#8b5cf6', '#06b6d4'];

  const pieData = expensesByCategory.map((item, index) => ({
    name: item.category,
    value: item.amount,
    color: COLORS[index % COLORS.length],
  }));

  const barData = last6MonthsBalance.map(item => ({
    month: item.month,
    Entradas: item.income / 100,
    Saídas: item.expenses / 100,
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4 md:mb-0">
          Dashboard
        </h2>
        <div className="flex items-center space-x-4">
          <input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
          />
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <div className="text-center">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              Saldo do Mês
            </h3>
            <p className={`text-3xl font-bold ${monthlyMetrics.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(monthlyMetrics.balance)}
            </p>
            <p className="text-sm text-gray-500 mt-1">
              {getMonthName(selectedMonth)}
            </p>
          </div>
        </Card>

        <Card>
          <div className="text-center">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              Entradas do Mês
            </h3>
            <p className="text-3xl font-bold text-green-600">
              {formatCurrency(monthlyMetrics.income)}
            </p>
            <p className="text-sm text-gray-500 mt-1">
              {getMonthName(selectedMonth)}
            </p>
          </div>
        </Card>

        <Card>
          <div className="text-center">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              Saídas do Mês
            </h3>
            <p className="text-3xl font-bold text-red-600">
              {formatCurrency(monthlyMetrics.expenses)}
            </p>
            <p className="text-sm text-gray-500 mt-1">
              {getMonthName(selectedMonth)}
            </p>
          </div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pie Chart - Expenses by Category */}
        <Card>
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
            Saídas por Categoria
          </h3>
          {expensesByCategory.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${((percent || 0) * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => formatCurrency(Number(value))} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-64 text-gray-500">
              Sem dados para exibir
            </div>
          )}
        </Card>

        {/* Bar Chart - Last 6 Months */}
        <Card>
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
            Entradas x Saídas (Últimos 6 Meses)
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={barData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip formatter={(value) => `R$ ${Number(value).toFixed(2)}`} />
              <Legend />
              <Bar dataKey="Entradas" fill="#16a34a" />
              <Bar dataKey="Saídas" fill="#dc2626" />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
          Atalhos Rápidos
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Button variant="secondary" size="sm">
            + Saída Alimentação
          </Button>
          <Button variant="secondary" size="sm">
            + Saída Transporte
          </Button>
          <Button variant="secondary" size="sm">
            + Entrada Salário
          </Button>
          <Button variant="secondary" size="sm">
            + Saída Lazer
          </Button>
        </div>
      </Card>

      {/* Empty State */}
      {transactions.length === 0 && (
        <Card>
          <div className="text-center py-8">
            <p className="text-gray-500 mb-4">
              Sem dados neste mês. Clique em + Adicionar para criar sua primeira movimentação.
            </p>
            <Button>+ Adicionar Movimentação</Button>
          </div>
        </Card>
      )}
    </div>
  );
};

export default Dashboard;

