import React, { useState, useEffect } from 'react';
import Modal from '../../components/Modal';
import Input from '../../components/Input';
import Select from '../../components/Select';
import CurrencyInput from '../../components/CurrencyInput';
import DatePicker from '../../components/DatePicker';
import Button from '../../components/Button';
import type { Transaction } from '../../db';
import { useToast } from '../../components/Toast';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (transaction: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt'>) => void;
  transaction?: Transaction | null;
}

const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  transaction,
}) => {
  const { addToast } = useToast();
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    type: 'saida' as 'entrada' | 'saida',
    amount: 0,
    category: '',
    subcategory: '',
    account: '',
    description: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (transaction) {
      setFormData({
        date: transaction.date,
        type: transaction.type,
        amount: transaction.amount,
        category: transaction.category,
        subcategory: transaction.subcategory || '',
        account: transaction.account || '',
        description: transaction.description || '',
      });
    } else {
      setFormData({
        date: new Date().toISOString().split('T')[0],
        type: 'saida',
        amount: 0,
        category: '',
        subcategory: '',
        account: '',
        description: '',
      });
    }
    setErrors({});
  }, [transaction, isOpen]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.date) {
      newErrors.date = 'Data é obrigatória';
    }

    if (formData.amount <= 0) {
      newErrors.amount = 'Valor deve ser maior que zero';
    }

    if (!formData.category.trim()) {
      newErrors.category = 'Categoria é obrigatória';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      addToast('Por favor, corrija os erros no formulário', 'error');
      return;
    }

    onSave(formData);
    addToast('Movimentação salva com sucesso!', 'success');
    onClose();
  };

  const handleSaveAndAddAnother = () => {
    if (!validateForm()) {
      addToast('Por favor, corrija os erros no formulário', 'error');
      return;
    }

    onSave(formData);
    addToast('Movimentação salva com sucesso!', 'success');
    
    // Reset form for new transaction
    setFormData({
      date: new Date().toISOString().split('T')[0],
      type: 'saida',
      amount: 0,
      category: '',
      subcategory: '',
      account: '',
      description: '',
    });
    setErrors({});
  };

  const typeOptions = [
    { value: 'entrada', label: 'Entrada' },
    { value: 'saida', label: 'Saída' },
  ];

  const categoryOptions = [
    { value: '', label: 'Selecione uma categoria' },
    { value: 'Alimentação', label: 'Alimentação' },
    { value: 'Transporte', label: 'Transporte' },
    { value: 'Lazer', label: 'Lazer' },
    { value: 'Saúde', label: 'Saúde' },
    { value: 'Educação', label: 'Educação' },
    { value: 'Casa', label: 'Casa' },
    { value: 'Salário', label: 'Salário' },
    { value: 'Freelance', label: 'Freelance' },
    { value: 'Investimentos', label: 'Investimentos' },
    { value: 'Outros', label: 'Outros' },
  ];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={transaction ? 'Editar Movimentação' : 'Nova Movimentação'}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <DatePicker
          label="Data"
          value={formData.date}
          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
          error={errors.date}
        />

        <Select
          label="Tipo"
          options={typeOptions}
          value={formData.type}
          onChange={(e) => setFormData({ ...formData, type: e.target.value as 'entrada' | 'saida' })}
        />

        <CurrencyInput
          label="Valor"
          value={formData.amount}
          onChange={(value) => setFormData({ ...formData, amount: value })}
          error={errors.amount}
        />

        <Select
          label="Categoria"
          options={categoryOptions}
          value={formData.category}
          onChange={(e) => setFormData({ ...formData, category: e.target.value })}
          error={errors.category}
        />

        <Input
          label="Subcategoria"
          value={formData.subcategory}
          onChange={(e) => setFormData({ ...formData, subcategory: e.target.value })}
          placeholder="Opcional"
        />

        <Input
          label="Conta/Cartão"
          value={formData.account}
          onChange={(e) => setFormData({ ...formData, account: e.target.value })}
          placeholder="Opcional"
        />

        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">
            Descrição
          </label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="shadow appearance-none border rounded-lg w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:border-transparent"
            rows={3}
            placeholder="Opcional"
          />
        </div>

        <div className="flex flex-col md:flex-row justify-end space-y-2 md:space-y-0 md:space-x-2 pt-4">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancelar
          </Button>
          {!transaction && (
            <Button type="button" variant="secondary" onClick={handleSaveAndAddAnother}>
              Salvar e Adicionar Outra
            </Button>
          )}
          <Button type="submit">
            Salvar
          </Button>
        </div>
      </form>
    </Modal>
  );
};

export default TransactionModal;

