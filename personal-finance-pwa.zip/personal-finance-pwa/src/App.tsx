import { useState } from 'react';
import './index.css';

function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [isDark, setIsDark] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle('dark');
  };

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'transactions', label: 'Movimentações' },
    { id: 'recurrings', label: 'Recorrentes' },
    { id: 'budgets', label: 'Orçamentos' },
    { id: 'rules', label: 'Regras' },
    { id: 'settings', label: 'Configurações' },
  ];

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-white">Dashboard</h2>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <p className="text-gray-600 dark:text-gray-300">
                Bem-vindo ao seu controle financeiro pessoal!
              </p>
              <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-green-50 dark:bg-green-900 p-4 rounded-lg">
                  <h3 className="text-lg font-medium text-green-800 dark:text-green-200">Saldo do Mês</h3>
                  <p className="text-2xl font-bold text-green-600 dark:text-green-400">R$ 0,00</p>
                </div>
                <div className="bg-blue-50 dark:bg-blue-900 p-4 rounded-lg">
                  <h3 className="text-lg font-medium text-blue-800 dark:text-blue-200">Entradas</h3>
                  <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">R$ 0,00</p>
                </div>
                <div className="bg-red-50 dark:bg-red-900 p-4 rounded-lg">
                  <h3 className="text-lg font-medium text-red-800 dark:text-red-200">Saídas</h3>
                  <p className="text-2xl font-bold text-red-600 dark:text-red-400">R$ 0,00</p>
                </div>
              </div>
            </div>
          </div>
        );
      default:
        return (
          <div className="text-center py-8">
            <h2 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">
              {menuItems.find(item => item.id === currentPage)?.label}
            </h2>
            <p className="text-gray-600 dark:text-gray-300">Em desenvolvimento...</p>
          </div>
        );
    }
  };

  return (
    <div className={`min-h-screen ${isDark ? 'dark' : ''}`}>
      {/* Topbar */}
      <header className="bg-white dark:bg-gray-800 shadow-md">
        <div className="max-w-6xl mx-auto px-4 md:px-6 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-xl md:text-2xl font-semibold text-gray-900 dark:text-white">
              Controle Financeiro
            </h1>
            
            <div className="flex items-center space-x-4">
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm">
                + Adicionar
              </button>
              
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
                aria-label="Alternar tema"
              >
                {isDark ? '☀️' : '🌙'}
              </button>
              
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="md:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
                aria-label="Menu"
              >
                ☰
              </button>
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex mt-4 space-x-6">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  currentPage === item.id
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>
          
          {/* Mobile Navigation */}
          {isMenuOpen && (
            <nav className="md:hidden mt-4 space-y-2">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentPage(item.id);
                    setIsMenuOpen(false);
                  }}
                  className={`block w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    currentPage === item.id
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto p-4 md:p-6 bg-gray-50 dark:bg-gray-900 min-h-screen">
        {renderCurrentPage()}
      </main>
    </div>
  );
}

export default App;

