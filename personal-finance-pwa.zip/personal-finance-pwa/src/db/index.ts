import Dexie from 'dexie';

export interface Transaction {
  id?: number;
  date: string; // ISO yyyy-mm-dd
  type: 'entrada' | 'saida';
  amount: number; // em centavos
  category: string;
  subcategory?: string;
  account?: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Recurring {
  id?: number;
  title: string;
  type: 'entrada' | 'saida';
  amount: number; // em centavos
  category: string;
  dayOfMonth: number; // 1..31
  active: boolean;
  lastEmitted?: string; // yyyy-mm
}

export interface Budget {
  id?: number;
  month: string; // yyyy-mm
  category: string;
  limit: number; // em centavos
}

export interface Rule {
  id?: number;
  keyword: string;
  category: string;
  subcategory?: string;
}

export class PersonalFinanceDB extends Dexie {
  transactions!: Dexie.Table<Transaction>;
  recurrings!: Dexie.Table<Recurring>;
  budgets!: Dexie.Table<Budget>;
  rules!: Dexie.Table<Rule>;

  constructor() {
    super('PersonalFinanceDB');
    this.version(1).stores({
      transactions: '++id, date, type, category',
      recurrings: '++id',
      budgets: '++id, month, category',
      rules: '++id, keyword',
    });
  }
}

export const db = new PersonalFinanceDB();


