import type { Transaction } from '../db';

export interface MonthlyMetrics {
  balance: number;
  income: number;
  expenses: number;
}

export interface CategoryExpense {
  category: string;
  amount: number;
  percentage: number;
}

export interface MonthlyBalance {
  month: string;
  income: number;
  expenses: number;
  balance: number;
}

export const calculateMonthlyMetrics = (
  transactions: Transaction[],
  month: string
): MonthlyMetrics => {
  const monthTransactions = transactions.filter(t => 
    t.date.startsWith(month)
  );

  const income = monthTransactions
    .filter(t => t.type === 'entrada')
    .reduce((sum, t) => sum + t.amount, 0);

  const expenses = monthTransactions
    .filter(t => t.type === 'saida')
    .reduce((sum, t) => sum + t.amount, 0);

  return {
    balance: income - expenses,
    income,
    expenses,
  };
};

export const calculateExpensesByCategory = (
  transactions: Transaction[],
  month: string
): CategoryExpense[] => {
  const monthTransactions = transactions.filter(t => 
    t.date.startsWith(month) && t.type === 'saida'
  );

  const totalExpenses = monthTransactions.reduce((sum, t) => sum + t.amount, 0);

  const categoryTotals = monthTransactions.reduce((acc, t) => {
    acc[t.category] = (acc[t.category] || 0) + t.amount;
    return acc;
  }, {} as Record<string, number>);

  return Object.entries(categoryTotals)
    .map(([category, amount]) => ({
      category,
      amount,
      percentage: totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0,
    }))
    .sort((a, b) => b.amount - a.amount);
};

export const calculateLast6MonthsBalance = (
  transactions: Transaction[]
): MonthlyBalance[] => {
  const now = new Date();
  const months: MonthlyBalance[] = [];

  for (let i = 5; i >= 0; i--) {
    const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const month = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
    
    const metrics = calculateMonthlyMetrics(transactions, month);
    
    months.push({
      month: date.toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' }),
      income: metrics.income,
      expenses: metrics.expenses,
      balance: metrics.balance,
    });
  }

  return months;
};

