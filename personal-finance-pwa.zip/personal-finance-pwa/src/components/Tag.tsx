import React from 'react';

interface TagProps {
  children: React.ReactNode;
  type?: 'entrada' | 'saida';
  className?: string;
}

const Tag: React.FC<TagProps> = ({
  children,
  type,
  className = '',
}) => {
  const baseStyles = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium';

  const typeStyles = {
    entrada: 'bg-green-100 text-green-800',
    saida: 'bg-red-100 text-red-800',
  };

  return (
    <span className={`${baseStyles} ${type ? typeStyles[type] : ''} ${className}`}>
      {children}
    </span>
  );
};

export default Tag;


