import React from 'react';
import DatePicker from './DatePicker';
import Button from './Button';

interface DateRangePickerProps {
  startDate: string;
  endDate: string;
  onStartDateChange: (date: string) => void;
  onEndDateChange: (date: string) => void;
  onCurrentMonthClick: () => void;
}

const DateRangePicker: React.FC<DateRangePickerProps> = ({
  startDate,
  endDate,
  onStartDateChange,
  onEndDateChange,
  onCurrentMonthClick,
}) => {
  return (
    <div className="flex flex-col md:flex-row items-center space-y-2 md:space-y-0 md:space-x-4 mb-4">
      <DatePicker
        label="Data Inicial"
        value={startDate}
        onChange={(e) => onStartDateChange(e.target.value)}
      />
      <DatePicker
        label="Data Final"
        value={endDate}
        onChange={(e) => onEndDateChange(e.target.value)}
      />
      <Button onClick={onCurrentMonthClick} variant="secondary" size="md">
        Mês Atual
      </Button>
    </div>
  );
};

export default DateRangePicker;


