import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';

interface FileDropzoneProps {
  onFileAccepted: (file: File) => void;
  acceptedFileTypes?: string[];
}

const FileDropzone: React.FC<FileDropzoneProps> = ({
  onFileAccepted,
  acceptedFileTypes = [
    'text/csv',
    'application/json',
    '.csv',
    '.json',
  ],
}) => {
  const [isDragActive, setIsDragActive] = useState(false);

  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      if (acceptedFiles.length > 0) {
        onFileAccepted(acceptedFiles[0]);
      }
      setIsDragActive(false);
    },
    [onFileAccepted]
  );

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    accept: acceptedFileTypes.reduce((acc, type) => ({ ...acc, [type]: [] }), {}),
    onDragEnter: () => setIsDragActive(true),
    onDragLeave: () => setIsDragActive(false),
  });

  return (
    <div
      {...getRootProps()}
      className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors duration-200 ${isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 bg-gray-50'}`}
    >
      <input {...getInputProps()} />
      <p className="text-gray-600">
        Arraste e solte um arquivo aqui, ou clique para selecionar
      </p>
      {acceptedFileTypes.length > 0 && (
        <p className="text-gray-500 text-sm mt-1">
          Tipos de arquivo aceitos: {acceptedFileTypes.join(', ')}
        </p>
      )}
    </div>
  );
};

export default FileDropzone;


