import React from 'react';

interface ProgressBarProps {
  progress: number; // 0-100
  color?: 'green' | 'yellow' | 'red';
  className?: string;
}

const ProgressBar: React.FC<ProgressBarProps> = ({
  progress,
  color,
  className = '',
}) => {
  let barColor = 'bg-green-500';
  if (color) {
    if (color === 'yellow') barColor = 'bg-yellow-500';
    if (color === 'red') barColor = 'bg-red-500';
  } else {
    if (progress >= 80 && progress < 100) barColor = 'bg-yellow-500';
    if (progress >= 100) barColor = 'bg-red-500';
  }

  return (
    <div className={`w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700 ${className}`}>
      <div
        className={`${barColor} h-2.5 rounded-full`}
        style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
      ></div>
    </div>
  );
};

export default ProgressBar;


