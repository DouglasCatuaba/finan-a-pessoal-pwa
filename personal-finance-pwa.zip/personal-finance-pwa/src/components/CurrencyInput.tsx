import React, { useState, useEffect } from 'react';
import { formatCurrency } from '../utils/formatCurrency';

interface CurrencyInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'value'> {
  label: string;
  value: number; // value in cents
  onChange: (value: number) => void;
  error?: string;
}

const CurrencyInput: React.FC<CurrencyInputProps> = ({
  label,
  value,
  onChange,
  error,
  id,
  className = '',
  ...props
}) => {
  const [displayValue, setDisplayValue] = useState<string>('');

  useEffect(() => {
    setDisplayValue(formatCurrency(value));
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value;
    // Remove all non-numeric characters except comma and period
    const cleanedValue = rawValue.replace(/[^0-9,.]/g, '');
    // Replace comma with period for consistent parsing
    const dotSeparatedValue = cleanedValue.replace(/,/g, '.');

    // Handle multiple periods (e.g., 1.2.3 -> 1.23)
    const parts = dotSeparatedValue.split('.');
    let parsedValue = parts[0];
    if (parts.length > 1) {
      parsedValue += '.' + parts.slice(1).join('');
    }

    const numberValue = parseFloat(parsedValue);

    if (!isNaN(numberValue)) {
      // Convert to cents
      onChange(Math.round(numberValue * 100));
    } else if (rawValue === '') {
      onChange(0);
    }
    setDisplayValue(rawValue); // Update display value immediately for user input
  };

  const handleBlur = () => {
    // Format the value when the input loses focus
    setDisplayValue(formatCurrency(value));
  };

  const inputId = id || label.toLowerCase().replace(/\s/g, '-');

  return (
    <div className="mb-4">
      <label htmlFor={inputId} className="block text-gray-700 text-sm font-bold mb-2">
        {label}
      </label>
      <input
        id={inputId}
        type="text"
        value={displayValue}
        onChange={handleChange}
        onBlur={handleBlur}
        className={`shadow appearance-none border rounded-lg w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:border-transparent ${error ? 'border-red-500' : ''} ${className}`}
        placeholder="Use vírgula ou ponto. Ex.: 45,90"
        {...props}
      />
      {error && <p className="text-red-600 text-xs italic mt-1">{error}</p>}
    </div>
  );
};

export default CurrencyInput;


